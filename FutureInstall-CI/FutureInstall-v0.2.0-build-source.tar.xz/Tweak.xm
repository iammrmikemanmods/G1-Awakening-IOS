// FutureInstall 0.2.0 — process-scoped, time-limited experiment.
// iPhone XR (A12), iOS 17.5.1, Dopamine 3 rootless.
// The hooks emulate *one* compatibility signal; they do not supply iOS 26 APIs.

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#include <stdlib.h>
#include <string.h>
#include "FIPolicy.h"

@interface MIBundle : NSObject
- (BOOL)isWatchApp;
@end

static NSString * const kFISettingsFile = @"/var/mobile/Library/Preferences/com.iammrmikeman.futureinstall.plist";
static CFStringRef const kFIReloadNotification = CFSTR("com.iammrmikeman.futureinstall/Reload");
static NSDictionary *gFIPreferences = nil;

static void FIReloadPreferences(void) {
    NSDictionary *fresh = [NSDictionary dictionaryWithContentsOfFile:kFISettingsFile];
    @synchronized ([NSProcessInfo class]) {
        gFIPreferences = [fresh isKindOfClass:[NSDictionary class]] ? [fresh copy] : @{};
    }
}

static NSDictionary *FIPreferencesSnapshot(void) {
    @synchronized ([NSProcessInfo class]) {
        return gFIPreferences ?: @{};
    }
}

static void FIOnPreferencesChanged(CFNotificationCenterRef center, void *observer,
                                   CFStringRef name, const void *object,
                                   CFDictionaryRef userInfo) {
    (void)center; (void)observer; (void)name; (void)object; (void)userInfo;
    FIReloadPreferences();
}

// NULL, malformed or non-ASCII strings cannot trigger an iOS version spoof.
static const char *FIASCIIString(id value) {
    if (![value isKindOfClass:[NSString class]]) return NULL;
    NSString *string = (NSString *)value;
    const char *data = [string cStringUsingEncoding:NSASCIIStringEncoding];
    if (!data || [string lengthOfBytesUsingEncoding:NSASCIIStringEncoding] != strlen(data)) return NULL;
    return data;
}

static NSString *FITargetVersion(NSDictionary *prefs) {
    id setting = prefs[@"spoofVersion"] ?: @"26.0.0";
    const char *version = FIASCIIString(setting);
    return (version && FIValidSpoofVersion(version)) ? setting : nil;
}

static BOOL FISessionIsActive(NSDictionary *prefs, NSString *modeKey, NSString *expiryKey) {
    id enabled = prefs[modeKey];
    id expiry = prefs[expiryKey];
    if (![enabled isKindOfClass:[NSNumber class]] ||
        ![expiry isKindOfClass:[NSNumber class]]) return NO;
    return FIActiveSession([enabled boolValue], [expiry doubleValue],
                           [[NSDate date] timeIntervalSince1970]);
}

// Limit the purchase hook to an HTTPS Apple App Store buyProduct endpoint.
// On other request paths, the original request remains byte-for-byte unchanged.
static BOOL FIIsAppleBuyRequest(NSURL *url) {
    if (![url isKindOfClass:[NSURL class]] ||
        ![[url scheme] isEqualToString:@"https"]) return NO;
    NSString *host = [[url host] lowercaseString];
    return [host isKindOfClass:[NSString class]] &&
           ([host isEqualToString:@"buy.itunes.apple.com"] ||
            [host hasSuffix:@"-buy.itunes.apple.com"]) &&
           ([[url path] isEqualToString:@"/WebObjects/MZBuy.woa/wa/buyProduct"] ||
            [[url path] isEqualToString:@"/MZBuy.woa/wa/buyProduct"]);
}

%group FIAppStore
%hook NSMutableURLRequest
- (void)setValue:(NSString *)value forHTTPHeaderField:(NSString *)field {
    NSDictionary *prefs = FIPreferencesSnapshot();
    if (!FISessionIsActive(prefs, @"storeClaimEnabled", @"storeClaimExpiresAt") ||
        ![field isKindOfClass:[NSString class]] ||
        [field caseInsensitiveCompare:@"User-Agent"] != NSOrderedSame ||
        ![value isKindOfClass:[NSString class]] ||
        !FIIsAppleBuyRequest(self.URL)) {
        %orig(value, field);
        return;
    }

    NSString *target = FITargetVersion(prefs);
    if (!target) { %orig(value, field); return; }

    // The UA must have a recognizable iOS/x.y token; otherwise don't insert
    // any invented version tokens into an unknown future request format.
    NSString *updated = [value stringByReplacingOccurrencesOfString:@"iOS/[0-9]+(?:\\.[0-9]+){1,2}(?=[ ;]|$)"
                                                           withString:[@"iOS/" stringByAppendingString:target]
                                                              options:NSRegularExpressionSearch
                                                                range:NSMakeRange(0, value.length)];
    %orig(updated, field);
}
%end
%end

%group FIInstaller
%hook MIBundle
- (BOOL)_isMinimumOSVersion:(id)minimum
      applicableToOSVersion:(id)runningVersion
                   requiredOS:(unsigned long long)requiredOS
                        error:(id *)error {
    NSDictionary *prefs = FIPreferencesSnapshot();
    if (!FISessionIsActive(prefs, @"installBypassEnabled", @"installBypassExpiresAt")) {
        return %orig(minimum, runningVersion, requiredOS, error);
    }
    // The installer method must advertise isWatchApp; never affect WatchKit.
    if ([self isWatchApp]) return %orig(minimum, runningVersion, requiredOS, error);

    NSString *target = FITargetVersion(prefs);
    const char *minStr = FIASCIIString(minimum);
    const char *actualStr = FIASCIIString(runningVersion);
    if (!target || !FIShouldSpoofMinimum(minStr, actualStr, FIASCIIString(target))) {
        return %orig(minimum, runningVersion, requiredOS, error);
    }
    // Call the original Apple validation, with *only* the OS version substituted.
    // Codesign, DRM, device features and newer runtime APIs are untouched.
    return %orig(minimum, target, requiredOS, error);
}
%end
%end

static BOOL FIBoolMethodSignature(Method method, unsigned int expectedArgs) {
    if (!method || method_getNumberOfArguments(method) != expectedArgs) return NO;
    char *result = method_copyReturnType(method);
    BOOL valid = (result != NULL && (result[0] == 'B' || result[0] == 'c') && result[1] == '\0');
    free(result);
    return valid;
}

// Some Obj-C ABIs encode directional qualifiers before the argument type.
static const char *FISkipTypeQualifiers(const char *type) {
    if (!type) return NULL;
    while (*type && strchr("rnNoORV", *type)) ++type;
    return type;
}

static BOOL FIInstallerMethodIsCompatible(Class bundle) {
    if (!bundle) return NO;
    Method isWatch = class_getInstanceMethod(bundle, @selector(isWatchApp));
    Method version = class_getInstanceMethod(bundle,
        sel_registerName("_isMinimumOSVersion:applicableToOSVersion:requiredOS:error:"));
    if (!FIBoolMethodSignature(isWatch, 2) || !FIBoolMethodSignature(version, 6)) return NO;
    const char *expected[] = {"@", "@", "Q", "^@"};
    for (unsigned int i = 0; i < 4; ++i) {
        char *actual = method_copyArgumentType(version, i + 2);
        // Obj-C object types sometimes encode their class name after '@'.
        const char *effective = FISkipTypeQualifiers(actual);
        BOOL matches = effective && strncmp(effective, expected[i], strlen(expected[i])) == 0;
        free(actual);
        if (!matches) return NO;
    }
    return YES;
}

%ctor {
    @autoreleasepool {
        NSString *processName = [[NSProcessInfo processInfo] processName];
        if (![processName isEqualToString:@"appstored"] &&
            ![processName isEqualToString:@"installd"]) return;

        FIReloadPreferences();
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                        NULL, FIOnPreferencesChanged,
                                        kFIReloadNotification, NULL,
                                        CFNotificationSuspensionBehaviorDeliverImmediately);
        if ([processName isEqualToString:@"appstored"]) {
            %init(FIAppStore);
            NSLog(@"[FutureInstall] appstored hook loaded; session permissions enforced");
        } else if (FIInstallerMethodIsCompatible(objc_getClass("MIBundle"))) {
            %init(FIInstaller);
            NSLog(@"[FutureInstall] installd hook loaded; signature and session checked");
        } else {
            NSLog(@"[FutureInstall] installd hook NOT installed: private ABI absent/unknown");
        }
    }
}
