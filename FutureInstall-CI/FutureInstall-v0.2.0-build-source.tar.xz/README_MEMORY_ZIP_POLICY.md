# ZIP / EXPORT / TRUST POLICY — FutureInstall 0.2.0

1. A source ZIP is never mislabeled as an executable `.deb`. It contains real text source, build configuration, tests, and documentation; no fake `.deb`, `.dylib`, `.ipa`, or emulated build log may be inserted.
2. The ZIP must preserve the *exact source-root* relative paths (GitHub drag-and-drop safe). Theos `layout/`, `FutureInstallPrefs/`, `.github/workflows/`, and manifest must remain intact.
3. The project package is `com.iammrmikeman.futureinstall`, architecture `iphoneos-arm64`, rootless `/var/jb/` layout, with `ellekit` and `preferenceloader` dependencies and firmware restricted to 17.x.
4. Only a macOS/Xcode/Theos compile can produce the planned genuine installable `.deb`. The separate compiled package validator must inspect actual Mach-O binaries, not file extensions.
5. Native C policy tests and source verification must pass before export; the SHA256 manifest must describe *all* files in the source ZIP other than the manifest itself.
6. User data, purchased apps, Apple credentials, on-device preferences, signed binaries, or private entitlements never enter a source ZIP.
7. Session mode is default-off with a fixed 600-second expiry. Any unexpected private method ABI must fail closed. Do not silently widen daemon/process scope.
8. Export trust status: `SOURCE_TESTED_ONLY`. CI compilation: `NOT_RUN` locally. Physical device tests: `NOT_RUN`. Apple Server acceptance: `UNKNOWN`. iOS 26 app execution: `NOT_RUN`.
9. Preserve previous exports as separate versioned archives. Never overwrite the supplied 0.1.0 source or claim it was tested.
10. After any test failure, report the failing check and do not release an experimental build as working.
