#ifndef FUTUREINSTALL_FIPOLICY_H
#define FUTUREINSTALL_FIPOLICY_H

// Pure C, single-source decision policy shared by the injected tweak, Settings,
// and executable native tests. Never modify the device's reported OS globally.
#include <stdbool.h>
#include <math.h>

#define FI_SESSION_SECONDS (600.0) // Ten minutes; enforced in each daemon.

typedef struct {
    unsigned int major;
    unsigned int minor;
    unsigned int patch;
} FIVersion;

// Parse ASCII version with one to three decimal components. Reject spaces,
// signs, leading/trailing dots, overly long values, overflow and Unicode.
static inline bool FIParseVersion(const char *s, FIVersion *out) {
    if (!s || !out) return false;
    unsigned int parts[3] = {0, 0, 0};
    unsigned int part = 0, digits = 0;
    for (const unsigned char *p = (const unsigned char *)s; ; ++p) {
        const unsigned char c = *p;
        if (c >= (unsigned char)'0' && c <= (unsigned char)'9') {
            if (++digits > 2) return false;
            parts[part] = parts[part] * 10u + (unsigned int)(c - (unsigned char)'0');
        } else if (c == (unsigned char)'.') {
            if (!digits || part == 2) return false;
            ++part;
            digits = 0;
        } else if (c == 0) {
            if (!digits) return false;
            break;
        } else {
            return false;
        }
    }
    out->major = parts[0];
    out->minor = parts[1];
    out->patch = parts[2];
    return true;
}

// Only the requested iOS 26 generation and intermediate versions are allowed.
// Require at least major.minor in user configuration.
static inline bool FIValidSpoofVersion(const char *s) {
    FIVersion v;
    if (!FIParseVersion(s, &v) || v.major < 18 || v.major > 26) return false;
    unsigned int dots = 0;
    for (const char *p = s; *p; ++p) if (*p == '.') ++dots;
    return dots >= 1 && dots <= 2;
}

static inline int FICompareVersions(FIVersion a, FIVersion b) {
    if (a.major != b.major) return (a.major > b.major) ? 1 : -1;
    if (a.minor != b.minor) return (a.minor > b.minor) ? 1 : -1;
    if (a.patch != b.patch) return (a.patch > b.patch) ? 1 : -1;
    return 0;
}

// Only alter compatibility checks that genuinely fail on the real OS but
// should pass for the requested target. All other checks go to Apple unmodified.
static inline bool FIShouldSpoofMinimum(const char *minimum,
                                         const char *running,
                                         const char *target) {
    FIVersion minV, runV, targetV;
    if (!minimum || !running || !target ||
        !FIValidSpoofVersion(target) ||
        !FIParseVersion(minimum, &minV) ||
        !FIParseVersion(running, &runV) ||
        !FIParseVersion(target, &targetV)) return false;
    return FICompareVersions(minV, runV) > 0 &&
           FICompareVersions(minV, targetV) <= 0;
}

// The launcher and daemon must agree. Reject missing/nonfinite/corrupt expiry
// and stale sessions. Require both a future expiry and a sane start time.
static inline bool FIActiveSession(bool enabled, double expiresAt, double now) {
    return enabled && isfinite(expiresAt) && isfinite(now) &&
           expiresAt > 0 && now < expiresAt &&
           now >= expiresAt - FI_SESSION_SECONDS;
}

#endif
