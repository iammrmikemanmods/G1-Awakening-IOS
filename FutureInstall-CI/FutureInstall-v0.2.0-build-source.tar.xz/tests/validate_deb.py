#!/usr/bin/env python3
"""Validate a real compiled rootless Sileo .deb on a macOS CI host.

This is NOT a substitute for a live iOS 17.5.1 test. Reject fake binaries.
"""
from __future__ import annotations
import pathlib
import plistlib
import subprocess
import sys
import tempfile

PKG = 'com.iammrmikeman.futureinstall'
PREFIX = pathlib.Path('var/jb/Library')
EXPECTED_FILES = {
    'MobileSubstrate/DynamicLibraries/FutureInstall.dylib',
    'MobileSubstrate/DynamicLibraries/FutureInstall.plist',
    'PreferenceLoader/Preferences/FutureInstall.plist',
}
MACHO_MAGICS = {
    b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
    b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe',
    b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe'
}

def command(*args: str) -> str:
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT)

def require_macho(path: pathlib.Path) -> None:
    if not path.is_file() or path.stat().st_size < 1024:
        raise RuntimeError(f'Binary not found/too small: {path}')
    if path.read_bytes()[:4] not in MACHO_MAGICS:
        raise RuntimeError(f'Not a Mach-O binary: {path}')

def validate(deb: pathlib.Path) -> None:
    if not deb.is_file() or deb.stat().st_size < 2048:
        raise RuntimeError(f'Nontrivial compiled Debian package missing: {deb}')
    fields = {k: command('dpkg-deb', '-f', str(deb), k).strip()
              for k in ('Package', 'Version', 'Architecture', 'Depends')}
    if fields['Package'] != PKG or fields['Version'] != '0.2.0' or \
       fields['Architecture'] != 'iphoneos-arm64':
        raise RuntimeError(f'Unexpected Debian control fields: {fields}')
    for dependency in ('firmware (>= 17.0)', 'firmware (<< 18.0)', 'ellekit', 'preferenceloader'):
        if dependency not in fields['Depends']:
            raise RuntimeError(f'Required dependency missing: {dependency} ({fields["Depends"]})')
    with tempfile.TemporaryDirectory(prefix='futureinstall-package-') as td:
        command('dpkg-deb', '-x', str(deb), td)
        root = pathlib.Path(td)
        for rel in EXPECTED_FILES:
            path = root / PREFIX / rel
            if not path.is_file():
                raise RuntimeError(f'Missing rootless payload: {path.relative_to(root)}')
        # Detect accidental rootful install layout regression.
        if (root / 'Library/MobileSubstrate/DynamicLibraries/FutureInstall.dylib').exists():
            raise RuntimeError('Rootful injection payload found')
        if (root / 'Library/PreferenceBundles/FutureInstallPrefs.bundle').exists():
            raise RuntimeError('Rootful preferences payload found')

        lib = root / PREFIX / 'MobileSubstrate/DynamicLibraries/FutureInstall.dylib'
        bundle = root / PREFIX / 'PreferenceBundles/FutureInstallPrefs.bundle'
        pref = bundle / 'FutureInstallPrefs'
        require_macho(lib)
        require_macho(pref)
        if 'arm64e' not in command('lipo', '-archs', str(lib)).split():
            raise RuntimeError('The injected system daemon library is missing arm64e')
        if not {'arm64', 'arm64e'}.intersection(command('lipo', '-archs', str(pref)).split()):
            raise RuntimeError('Preference bundle missing an ARM64 slice')

        with (root / PREFIX / 'MobileSubstrate/DynamicLibraries/FutureInstall.plist').open('rb') as f:
            filter_config = plistlib.load(f)
        if filter_config.get('Filter', {}).get('Executables') != ['appstored', 'installd']:
            raise RuntimeError('Injector process allowlist differs from reviewed source')
        with (bundle / 'Info.plist').open('rb') as f:
            info = plistlib.load(f)
        if info.get('CFBundleExecutable') != 'FutureInstallPrefs':
            raise RuntimeError('Missing/incorrect Settings executable declaration')
        if not (bundle / 'Root.plist').is_file():
            raise RuntimeError('Settings Root.plist not packaged')

    print(f'PASS: real rootless Debian structure, architecture, Mach-O, filters, preferences: {deb}')

if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit('usage: tests/validate_deb.py packages/*.deb')
    for item in sys.argv[1:]:
        validate(pathlib.Path(item))
