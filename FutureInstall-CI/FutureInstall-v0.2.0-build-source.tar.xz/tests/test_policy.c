#include "../FIPolicy.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

int main(void) {
    FIVersion v;
    assert(FIParseVersion("17.5.1", &v) && v.major == 17 && v.minor == 5 && v.patch == 1);
    assert(FIParseVersion("26", &v) && v.major == 26);
    assert(FIParseVersion("26.0", &v) && v.patch == 0);
    const char *invalid[] = {"", ".26", "26.", "26..1", "26.1.2.3", "26x0",
                             " 26.0", "26.0 ", "+26.0", "26.000", "999.0", "26/0", NULL};
    for (int i = 0; invalid[i] != NULL; ++i) assert(!FIParseVersion(invalid[i], &v));
    assert(!FIParseVersion(NULL, &v) && !FIParseVersion("26.0", NULL));
    assert(FIValidSpoofVersion("26.0.0"));
    assert(FIValidSpoofVersion("18.0"));
    assert(FIValidSpoofVersion("26.99.99"));
    assert(!FIValidSpoofVersion("17.5.1"));
    assert(!FIValidSpoofVersion("27.0.0"));
    assert(!FIValidSpoofVersion("99.0.0"));
    assert(!FIValidSpoofVersion("26"));
    assert(!FIValidSpoofVersion(NULL));
    assert(!FIValidSpoofVersion("26.100"));

    // An app requiring iOS 26 can be compared against 17.5.1 if target >= 26.
    assert(FIShouldSpoofMinimum("26.0", "17.5.1", "26.0.0"));
    assert(FIShouldSpoofMinimum("18.3", "17.5.1", "26.0.0"));
    assert(FIShouldSpoofMinimum("26", "17.5.1", "26.0.0"));
    // Already supported apps must NEVER have the version check changed.
    assert(!FIShouldSpoofMinimum("16.0", "17.5.1", "26.0.0"));
    assert(!FIShouldSpoofMinimum("17.5.1", "17.5.1", "26.0.0"));
    // Target lower than required is never spoofed.
    assert(!FIShouldSpoofMinimum("26.0.1", "17.5.1", "26.0.0"));
    assert(!FIShouldSpoofMinimum("27.0", "17.5.1", "26.0.0"));
    assert(!FIShouldSpoofMinimum("26.0", "17.5.1", "99.0.0"));
    assert(!FIShouldSpoofMinimum("26.0", "17.5.1", "invalid"));
    assert(!FIShouldSpoofMinimum(NULL, "17.5.1", "26.0.0"));
    assert(!FIShouldSpoofMinimum("26.0", NULL, "26.0.0"));
    assert(!FIShouldSpoofMinimum("26.0", "17.5.1", NULL));

    const double start = 1793512345.0;
    const double expiry = start + FI_SESSION_SECONDS;
    assert(FIActiveSession(true, expiry, start));
    assert(FIActiveSession(true, expiry, expiry - 0.1));
    assert(!FIActiveSession(true, expiry, expiry));
    assert(!FIActiveSession(true, expiry, expiry + 1));
    assert(!FIActiveSession(true, expiry, start - 1));
    assert(!FIActiveSession(false, expiry, start));
    assert(!FIActiveSession(true, 0, start));
    assert(!FIActiveSession(true, NAN, start));
    assert(!FIActiveSession(true, INFINITY, start));
    assert(!FIActiveSession(true, expiry, NAN));
    puts("PASS: 34+ native policy assertions (real C code shared with tweak and Settings)");
    return 0;
}
