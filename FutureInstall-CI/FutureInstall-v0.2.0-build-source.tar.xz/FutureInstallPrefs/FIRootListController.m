#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#include "../FIPolicy.h"
#include <string.h>

static NSString * const kFIConfigPath = @"/var/mobile/Library/Preferences/com.iammrmikeman.futureinstall.plist";
static CFStringRef const kFIReloadNotification = CFSTR("com.iammrmikeman.futureinstall/Reload");

@interface FIRootListController : PSListController
@end

@implementation FIRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:kFIConfigPath];
    NSString *key = [specifier propertyForKey:@"key"];
    id value = key ? settings[key] : nil;
    if ([key isEqualToString:@"storeClaimEnabled"] ||
        [key isEqualToString:@"installBypassEnabled"]) {
        NSString *expiryKey = [key isEqualToString:@"storeClaimEnabled"] ?
                             @"storeClaimExpiresAt" : @"installBypassExpiresAt";
        id expiry = settings[expiryKey];
        return @([value isKindOfClass:[NSNumber class]] &&
                 [expiry isKindOfClass:[NSNumber class]] &&
                 FIActiveSession([value boolValue], [expiry doubleValue],
                                 [[NSDate date] timeIntervalSince1970]));
    }
    return value ?: [specifier propertyForKey:@"default"];
}

static BOOL FIValidTarget(NSString *target) {
    if (![target isKindOfClass:[NSString class]]) return NO;
    const char *ascii = [target cStringUsingEncoding:NSASCIIStringEncoding];
    return ascii && [target lengthOfBytesUsingEncoding:NSASCIIStringEncoding] == strlen(ascii) &&
           FIValidSpoofVersion(ascii);
}

- (void)FIShowAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                               message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (!key || !value) return;
    if ([key isEqualToString:@"spoofVersion"] && !FIValidTarget(value)) {
        [self FIShowAlert:@"Invalid iOS version"
                  message:@"Enter iOS 18.0 to 26.99.99 (for example, 26.0.0). No changes were made."];
        [self reloadSpecifiers];
        return;
    }
    BOOL claim = [key isEqualToString:@"storeClaimEnabled"];
    BOOL install = [key isEqualToString:@"installBypassEnabled"];
    if ((claim || install) && ![value isKindOfClass:[NSNumber class]]) return;

    NSMutableDictionary *settings = [[NSMutableDictionary alloc] initWithContentsOfFile:kFIConfigPath];
    if (!settings) settings = [NSMutableDictionary dictionary];
    if ((claim || install) && [value boolValue] &&
        !FIValidTarget(settings[@"spoofVersion"] ?: @"26.0.0")) {
        [self FIShowAlert:@"Cannot enable" message:@"Correct the iOS spoof version first."];
        [self reloadSpecifiers];
        return;
    }

    settings[key] = value;
    if (claim || install) {
        NSString *expiryKey = claim ? @"storeClaimExpiresAt" : @"installBypassExpiresAt";
        settings[expiryKey] = [value boolValue] ?
            @([[NSDate date] timeIntervalSince1970] + FI_SESSION_SECONDS) : @(0);
    }

    if (![settings writeToFile:kFIConfigPath atomically:YES]) {
        [self FIShowAlert:@"Cannot save settings"
                  message:@"Check the jailbreak and permissions on /var/mobile/Library/Preferences."];
        [self reloadSpecifiers];
        return;
    }
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         kFIReloadNotification, NULL, NULL, true);
}
@end
